@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.google.com/kml/ext/2.2", xmlns = {
    @javax.xml.bind.annotation.XmlNs( prefix = "gx", namespaceURI = "http://www.google.com/kml/ext/2.2" )
},
elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.micromata.opengis.kml.v_2_2_0.gx;
