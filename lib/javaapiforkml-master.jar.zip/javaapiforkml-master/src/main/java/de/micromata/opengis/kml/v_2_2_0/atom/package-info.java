@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.w3.org/2005/Atom", xmlns = {
    @javax.xml.bind.annotation.XmlNs( prefix = "atom", namespaceURI = "http://www.w3.org/2005/Atom" )
}, elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.micromata.opengis.kml.v_2_2_0.atom;
