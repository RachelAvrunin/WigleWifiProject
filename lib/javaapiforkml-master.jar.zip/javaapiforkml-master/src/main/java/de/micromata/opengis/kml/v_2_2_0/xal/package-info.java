@javax.xml.bind.annotation.XmlSchema(namespace = "urn:oasis:names:tc:ciq:xsdschema:xAL:2.0", xmlns = {
    @javax.xml.bind.annotation.XmlNs( prefix = "xal", namespaceURI = "urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" )
}, elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.micromata.opengis.kml.v_2_2_0.xal;
